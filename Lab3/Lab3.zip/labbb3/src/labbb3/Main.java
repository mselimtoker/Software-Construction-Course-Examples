package labbb3;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        Boss boss1 = new Boss("01/01/1978",12345);
        Address address1 = new Address("Foo", "Izmir", "35100");
	    Employee emp1 = new Employee("Mert","Hasret",100000,boss1,address1);
	    Employee emp2 = new Employee("Ahmet","BongBong", 20000,boss1,new Address("Bodo","Logo","12345"));
        Employee emp3 = new Employee("Jamie","Esese", 10000,boss1,new Address("Bada","Logo","32145"));
        Employee emp4 = new Employee("Naisu","Baisu", 70000,boss1,new Address("Bede","Logo","34125"));
        Employee emp5 = new Employee("Ching Chang","Chong", 80000,boss1,new Address("Heykel","Izmır","54321"));
        Employee emp6 = new Employee("James","Bond", 90000,boss1,new Address("Büdü","Logo","12345"));
        Employee emp7 = new Employee("Tra","Lala", 25000,boss1,new Address("Bödö","Izmir","54123"));
        Employee emp8 = new Employee("Dope","Cope", 18000,boss1,new Address("Atatürk","Izmir","12345"));
        ArrayList<Employee> empList = new ArrayList();
        empList.add(emp1);
        empList.add(emp2);
        empList.add(emp3);
        empList.add(emp4);
        empList.add(emp5);
        empList.add(emp6);
        empList.add(emp7);
        empList.add(emp8);

        System.out.println(emp1);
        System.out.println("--> Setting salary to -100");
        emp1.setMonthlySalary(-100);
        System.out.println(emp1);
        System.out.println("--> Setting raise percentage to -90");
        emp1.calculateSomething(-90,1000);
        System.out.println(emp1);
        System.out.println("--> Setting raise percentage to 100");
        emp1.calculateSomething(100,1000);
        System.out.println(emp1);
        System.out.println("--> Yearly salary of the employee is : "  + emp1.getYearlySalary());

        System.out.println("----------------END OF BASIC OPERATIONS TESTS-------------------");

        for(int i=0;i<empList.size();i++){
            if(empList.get(i).address.getCity().equalsIgnoreCase("Izmir") && empList.get(i).getMonthlySalary()>0){
                System.out.println(empList.get(i));
            }
        }
    }
}

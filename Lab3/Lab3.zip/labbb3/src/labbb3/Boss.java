package labbb3;


public class Boss extends Person{
    private String birthdayOfBoss;
    private double profitOfCompany;

    public Boss(String birthdayOfBoss, double profitOfCompany) {
        this.birthdayOfBoss = birthdayOfBoss;
        this.profitOfCompany = profitOfCompany;
    }

    public String getBirthdayOfBoss() {
        return birthdayOfBoss;
    }

    public void setBirthdayOfBoss(String birthdayOfBoss) {
        this.birthdayOfBoss = birthdayOfBoss;
    }

    public double getProfitOfCompany() {
        return profitOfCompany;
    }

    public void setProfitOfCompany(double profitOfCompany) {
        this.profitOfCompany = profitOfCompany;
    }

    @Override
    public String toString() {
        return
                "birthdayOfBoss : '" + birthdayOfBoss + '\'' +
                ", profitOfCompany : " + profitOfCompany;
    }
}

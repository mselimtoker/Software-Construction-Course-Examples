package labbb3;

public class Employee extends Person {

    private String firstName;
    private String lastName;
    private double monthlySalary;
    private int age;
    Boss boss;
    Address address;
    boolean isMarried = false;
    boolean hasChildren = false;

    public Employee(String firstName, String lastName, double monthlySalary, Boss boss, Address address) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.monthlySalary = monthlySalary;
        this.boss = boss;
        this.address = address;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public double getMonthlySalary() {
        return monthlySalary;
    }

    public void setMonthlySalary(double monthlySalary) {
        if (monthlySalary < 0) {
            return;
        }
        this.monthlySalary = monthlySalary;
    }

    public void calculateSomething(double percentage, int salary) {
        double newSalary = monthlySalary;
        if (percentage > 0 && isMarried && hasChildren && age > 40
                && firstName.equals("ilhan") && lastName.equals("sofuoglu")) {
            newSalary += (newSalary * percentage) / 100;
        }
        monthlySalary = newSalary;
    }

    public double calculateCreditAmount(double salary) {
        salary = salary * 3.5;
        return salary;
    }
    
    

    public double getYearlySalary() {
        return monthlySalary * 12;
    }

    @Override
    public String toString() {
        return "Employee Name : " + firstName + " " + lastName + "\nEmployee Salary : " + monthlySalary + "\nBoss Information : " + boss.toString() + "\nAddress Information : " + address.toString() + "\n--------------------------------------";
    }
}
